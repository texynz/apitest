/* MedicalEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."medical_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "lat" REAL,
    "lng" REAL,
    "mentalLevel" INTEGER,
    "physicalPriority" TEXT,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "updateDateTime" timestamptz
);

ALTER TABLE
    "app"."medical_event"
ADD
    CONSTRAINT "medical_event_pkey" PRIMARY KEY ("id");

/* SuppliesEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."supply_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "foodSupply" INTEGER,
    "lat" REAL,
    "lng" REAL,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "updateDateTime" timestamptz,
    "waterSupply" INTEGER
);

ALTER TABLE
    "app"."supply_event"
ADD
    CONSTRAINT "supply_event_pkey" PRIMARY KEY ("id");

/* InfrastructureEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."infrastructure_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "blocked" BOOLEAN,
    "cracks" BOOLEAN,
    "damageLevel" INTEGER,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "lat" REAL,
    "lng" REAL,
    "looseChips" BOOLEAN,
    "potHoles" BOOLEAN,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "slips" BOOLEAN,
    "updateDateTime" timestamptz
);

ALTER TABLE
    "app"."infrastructure_event"
ADD
    CONSTRAINT "infrastructure_event_pkey" PRIMARY KEY ("id");