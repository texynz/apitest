/* MedicalEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."medical_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "lat" REAL,
    "lng" REAL,
    "mentalLevel" INTEGER,
    "physicalPriority" TEXT,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "updateDateTime" timestamptz
);

ALTER TABLE
    "app"."medical_event"
ADD
    CONSTRAINT "medical_event_pkey" PRIMARY KEY ("id");