/* SuppliesEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."supply_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "foodSupply" INTEGER,
    "lat" REAL,
    "lng" REAL,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "updateDateTime" timestamptz,
    "waterSupply" INTEGER
);

ALTER TABLE
    "app"."supply_event"
ADD
    CONSTRAINT "supply_event_pkey" PRIMARY KEY ("id");