/* InfrastructureEvent Table Schema: postgresql */
CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE "app"."infrastructure_event" (
    "id" TEXT,
    "createdAt" timestamptz,
    "updatedAt" timestamptz,
    "blocked" BOOLEAN,
    "cracks" BOOLEAN,
    "damageLevel" INTEGER,
    "dataCredibility" INTEGER,
    "dataReliability" TEXT,
    "eventid" TEXT,
    "lat" REAL,
    "lng" REAL,
    "looseChips" BOOLEAN,
    "potHoles" BOOLEAN,
    "reportDateTime" timestamptz,
    "reportType" TEXT,
    "slips" BOOLEAN,
    "updateDateTime" timestamptz
);

ALTER TABLE
    "app"."infrastructure_event"
ADD
    CONSTRAINT "infrastructure_event_pkey" PRIMARY KEY ("id");