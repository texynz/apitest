// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import { MedicalEvent, MedicalEventGatewayInterface } from '../entities';
import Viewer from '../server/viewer';

export interface CreateMedicalResponseUsecaseInput {
    medicalEvent: {
        eventid: string;
        lat: number;
        lng: number;
        mentalLevel: number;
        physicalPriority: string;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
    };
}

export interface CreateMedicalResponseUsecaseOutput {
    success: boolean;
    medicalEvent?: MedicalEvent;
}

export default class CreateMedicalResponseUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            medicalEvent: stdlib.validation
                .object()
                .keys({
                    eventid: MedicalEvent.EVENTID_VALIDATION.required(),
                    lat: MedicalEvent.LAT_VALIDATION.required(),
                    lng: MedicalEvent.LNG_VALIDATION.required(),
                    mentalLevel: MedicalEvent.MENTAL_LEVEL_VALIDATION.required(),
                    physicalPriority: MedicalEvent.PHYSICAL_PRIORITY_VALIDATION.required(),
                    reportDateTime: MedicalEvent.REPORT_DATE_TIME_VALIDATION.required(),
                    reportType: MedicalEvent.REPORT_TYPE_VALIDATION.required(),
                    updateDateTime: MedicalEvent.UPDATE_DATE_TIME_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [MedicalEventGatewayInterface];

    private readonly now: Date;
    private readonly medicalEventGateway: MedicalEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        MedicalEventGatewayInterface: MedicalEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.medicalEventGateway = dependencies.MedicalEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: CreateMedicalResponseUsecaseInput,
    ): Promise<CreateMedicalResponseUsecaseOutput> {
        const output: CreateMedicalResponseUsecaseOutput = {
            success: false,
            medicalEvent: undefined,
        };

        let medicalEvent: MedicalEvent;
        let medicalEventIdIntegrity;
        let medicalEventIntegrity;

        medicalEvent = new MedicalEvent(viewer, {});

        medicalEvent.id = MedicalEvent.genId();

        medicalEvent.createdAt = this.now;

        medicalEvent.updatedAt = this.now;

        medicalEvent.eventid = input.medicalEvent.eventid;

        medicalEvent.lat = input.medicalEvent.lat;

        medicalEvent.lng = input.medicalEvent.lng;

        medicalEvent.reportDateTime = input.medicalEvent.reportDateTime;

        medicalEvent.updateDateTime = input.medicalEvent.updateDateTime;

        medicalEvent.dataReliability = `F`;

        medicalEvent.dataCredibility = 6;

        medicalEvent.reportType = input.medicalEvent.reportType;

        medicalEvent.physicalPriority = input.medicalEvent.physicalPriority;

        medicalEvent.mentalLevel = input.medicalEvent.mentalLevel;

        medicalEventIntegrity = true;
        medicalEventIdIntegrity = await MedicalEvent.checkIdIntegrity(
            viewer,
            this.medicalEventGateway,
            medicalEvent,
        );
        if (!medicalEventIdIntegrity) {
            medicalEventIntegrity = false;
        }
        if (!medicalEventIntegrity) {
            return output;
        }

        medicalEvent = await MedicalEvent.createMedicalEvent(
            viewer,
            this.medicalEventGateway,
            medicalEvent,
        );
        if (!medicalEvent) {
            return output;
        }

        output.medicalEvent = medicalEvent;

        output.success = true;
        return output;
    }
}
