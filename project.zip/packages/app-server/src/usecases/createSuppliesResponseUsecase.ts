// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import { SuppliesEvent, SuppliesEventGatewayInterface } from '../entities';
import Viewer from '../server/viewer';

export interface CreateSuppliesResponseUsecaseInput {
    suppliesEvent: {
        eventid: string;
        foodSupply: number;
        lat: number;
        lng: number;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
        waterSupply: number;
    };
}

export interface CreateSuppliesResponseUsecaseOutput {
    success: boolean;
    suppliesEvent?: SuppliesEvent;
}

export default class CreateSuppliesResponseUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            suppliesEvent: stdlib.validation
                .object()
                .keys({
                    eventid: SuppliesEvent.EVENTID_VALIDATION.required(),
                    foodSupply: SuppliesEvent.FOOD_SUPPLY_VALIDATION.required(),
                    lat: SuppliesEvent.LAT_VALIDATION.required(),
                    lng: SuppliesEvent.LNG_VALIDATION.required(),
                    reportDateTime: SuppliesEvent.REPORT_DATE_TIME_VALIDATION.required(),
                    reportType: SuppliesEvent.REPORT_TYPE_VALIDATION.required(),
                    updateDateTime: SuppliesEvent.UPDATE_DATE_TIME_VALIDATION.required(),
                    waterSupply: SuppliesEvent.WATER_SUPPLY_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [SuppliesEventGatewayInterface];

    private readonly now: Date;
    private readonly suppliesEventGateway: SuppliesEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        SuppliesEventGatewayInterface: SuppliesEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.suppliesEventGateway = dependencies.SuppliesEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: CreateSuppliesResponseUsecaseInput,
    ): Promise<CreateSuppliesResponseUsecaseOutput> {
        const output: CreateSuppliesResponseUsecaseOutput = {
            success: false,
            suppliesEvent: undefined,
        };

        let suppliesEvent: SuppliesEvent;
        let suppliesEventIdIntegrity;
        let suppliesEventIntegrity;

        suppliesEvent = new SuppliesEvent(viewer, {});

        suppliesEvent.id = SuppliesEvent.genId();

        suppliesEvent.createdAt = this.now;

        suppliesEvent.updatedAt = this.now;

        suppliesEvent.eventid = input.suppliesEvent.eventid;

        suppliesEvent.lat = input.suppliesEvent.lat;

        suppliesEvent.lng = input.suppliesEvent.lng;

        suppliesEvent.reportDateTime = input.suppliesEvent.reportDateTime;

        suppliesEvent.updateDateTime = input.suppliesEvent.updateDateTime;

        suppliesEvent.dataReliability = `F`;

        suppliesEvent.dataCredibility = 6;

        suppliesEvent.reportType = input.suppliesEvent.reportType;

        suppliesEvent.waterSupply = input.suppliesEvent.waterSupply;

        suppliesEvent.foodSupply = input.suppliesEvent.foodSupply;

        suppliesEventIntegrity = true;
        suppliesEventIdIntegrity = await SuppliesEvent.checkIdIntegrity(
            viewer,
            this.suppliesEventGateway,
            suppliesEvent,
        );
        if (!suppliesEventIdIntegrity) {
            suppliesEventIntegrity = false;
        }
        if (!suppliesEventIntegrity) {
            return output;
        }

        suppliesEvent = await SuppliesEvent.createSuppliesEvent(
            viewer,
            this.suppliesEventGateway,
            suppliesEvent,
        );
        if (!suppliesEvent) {
            return output;
        }

        output.suppliesEvent = suppliesEvent;

        output.success = true;
        return output;
    }
}
