// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import { MedicalEvent, MedicalEventGatewayInterface } from '../entities';
import Viewer from '../server/viewer';

export interface GetAllMedicalUsecaseInput {
    medicalEvent: {
        id: string;
    };
}

export interface GetAllMedicalUsecaseOutput {
    success: boolean;
    medicalEvent?: MedicalEvent;
}

export default class GetAllMedicalUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            medicalEvent: stdlib.validation
                .object()
                .keys({
                    id: MedicalEvent.ID_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [MedicalEventGatewayInterface];

    private readonly now: Date;
    private readonly medicalEventGateway: MedicalEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        MedicalEventGatewayInterface: MedicalEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.medicalEventGateway = dependencies.MedicalEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: GetAllMedicalUsecaseInput,
    ): Promise<GetAllMedicalUsecaseOutput> {
        const output: GetAllMedicalUsecaseOutput = {
            success: false,
            medicalEvent: undefined,
        };

        let medicalEvent: MedicalEvent;

        medicalEvent = await MedicalEvent.genMedicalEventById(
            viewer,
            this.medicalEventGateway,
            input.medicalEvent.id,
        );
        if (!medicalEvent) {
            return output;
        }

        output.medicalEvent = medicalEvent;

        output.success = true;
        return output;
    }
}
