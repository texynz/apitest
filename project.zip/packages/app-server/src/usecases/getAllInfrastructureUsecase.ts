// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    InfrastructureEvent,
    InfrastructureEventGatewayInterface,
} from '../entities';
import Viewer from '../server/viewer';

export interface GetAllInfrastructureUsecaseInput {
    infrastructureEvent: {
        id: string;
    };
}

export interface GetAllInfrastructureUsecaseOutput {
    success: boolean;
    infrastructureEvent?: InfrastructureEvent;
}

export default class GetAllInfrastructureUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            infrastructureEvent: stdlib.validation
                .object()
                .keys({
                    id: InfrastructureEvent.ID_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [InfrastructureEventGatewayInterface];

    private readonly now: Date;
    private readonly infrastructureEventGateway: InfrastructureEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        InfrastructureEventGatewayInterface: InfrastructureEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.infrastructureEventGateway =
            dependencies.InfrastructureEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: GetAllInfrastructureUsecaseInput,
    ): Promise<GetAllInfrastructureUsecaseOutput> {
        const output: GetAllInfrastructureUsecaseOutput = {
            success: false,
            infrastructureEvent: undefined,
        };

        let infrastructureEvent: InfrastructureEvent;

        infrastructureEvent = await InfrastructureEvent.genInfrastructureEventById(
            viewer,
            this.infrastructureEventGateway,
            input.infrastructureEvent.id,
        );
        if (!infrastructureEvent) {
            return output;
        }

        output.infrastructureEvent = infrastructureEvent;

        output.success = true;
        return output;
    }
}
