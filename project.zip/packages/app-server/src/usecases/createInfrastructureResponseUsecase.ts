// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    InfrastructureEvent,
    InfrastructureEventGatewayInterface,
} from '../entities';
import Viewer from '../server/viewer';

export interface CreateInfrastructureResponseUsecaseInput {
    infrastructureEvent: {
        blocked: boolean;
        cracks: boolean;
        damageLevel: number;
        eventid: string;
        lat: number;
        lng: number;
        looseChips: boolean;
        potHoles: boolean;
        reportDateTime: Date;
        reportType: string;
        slips: boolean;
        updateDateTime: Date;
    };
}

export interface CreateInfrastructureResponseUsecaseOutput {
    success: boolean;
    infrastructureEvent?: InfrastructureEvent;
}

export default class CreateInfrastructureResponseUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            infrastructureEvent: stdlib.validation
                .object()
                .keys({
                    blocked: InfrastructureEvent.BLOCKED_VALIDATION.required(),
                    cracks: InfrastructureEvent.CRACKS_VALIDATION.required(),
                    damageLevel: InfrastructureEvent.DAMAGE_LEVEL_VALIDATION.required(),
                    eventid: InfrastructureEvent.EVENTID_VALIDATION.required(),
                    lat: InfrastructureEvent.LAT_VALIDATION.required(),
                    lng: InfrastructureEvent.LNG_VALIDATION.required(),
                    looseChips: InfrastructureEvent.LOOSE_CHIPS_VALIDATION.required(),
                    potHoles: InfrastructureEvent.POT_HOLES_VALIDATION.required(),
                    reportDateTime: InfrastructureEvent.REPORT_DATE_TIME_VALIDATION.required(),
                    reportType: InfrastructureEvent.REPORT_TYPE_VALIDATION.required(),
                    slips: InfrastructureEvent.SLIPS_VALIDATION.required(),
                    updateDateTime: InfrastructureEvent.UPDATE_DATE_TIME_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [InfrastructureEventGatewayInterface];

    private readonly now: Date;
    private readonly infrastructureEventGateway: InfrastructureEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        InfrastructureEventGatewayInterface: InfrastructureEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.infrastructureEventGateway =
            dependencies.InfrastructureEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: CreateInfrastructureResponseUsecaseInput,
    ): Promise<CreateInfrastructureResponseUsecaseOutput> {
        const output: CreateInfrastructureResponseUsecaseOutput = {
            success: false,
            infrastructureEvent: undefined,
        };

        let infrastructureEvent: InfrastructureEvent;
        let infrastructureEventIdIntegrity;
        let infrastructureEventIntegrity;

        infrastructureEvent = new InfrastructureEvent(viewer, {});

        infrastructureEvent.id = InfrastructureEvent.genId();

        infrastructureEvent.createdAt = this.now;

        infrastructureEvent.updatedAt = this.now;

        infrastructureEvent.eventid = input.infrastructureEvent.eventid;

        infrastructureEvent.lat = input.infrastructureEvent.lat;

        infrastructureEvent.lng = input.infrastructureEvent.lng;

        infrastructureEvent.reportDateTime =
            input.infrastructureEvent.reportDateTime;

        infrastructureEvent.updateDateTime =
            input.infrastructureEvent.updateDateTime;

        infrastructureEvent.dataReliability = `F`;

        infrastructureEvent.dataCredibility = 6;

        infrastructureEvent.reportType = input.infrastructureEvent.reportType;

        infrastructureEvent.damageLevel = input.infrastructureEvent.damageLevel;

        infrastructureEvent.looseChips = input.infrastructureEvent.looseChips;

        infrastructureEvent.potHoles = input.infrastructureEvent.potHoles;

        infrastructureEvent.cracks = input.infrastructureEvent.cracks;

        infrastructureEvent.slips = input.infrastructureEvent.slips;

        infrastructureEvent.blocked = input.infrastructureEvent.blocked;

        infrastructureEventIntegrity = true;
        infrastructureEventIdIntegrity = await InfrastructureEvent.checkIdIntegrity(
            viewer,
            this.infrastructureEventGateway,
            infrastructureEvent,
        );
        if (!infrastructureEventIdIntegrity) {
            infrastructureEventIntegrity = false;
        }
        if (!infrastructureEventIntegrity) {
            return output;
        }

        infrastructureEvent = await InfrastructureEvent.createInfrastructureEvent(
            viewer,
            this.infrastructureEventGateway,
            infrastructureEvent,
        );
        if (!infrastructureEvent) {
            return output;
        }

        output.infrastructureEvent = infrastructureEvent;

        output.success = true;
        return output;
    }
}
