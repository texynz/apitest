// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import { SuppliesEvent, SuppliesEventGatewayInterface } from '../entities';
import Viewer from '../server/viewer';

export interface GetAllSuppliesUsecaseInput {
    suppliesEvent: {
        id: string;
    };
}

export interface GetAllSuppliesUsecaseOutput {
    success: boolean;
    suppliesEvent?: SuppliesEvent;
}

export default class GetAllSuppliesUsecase {
    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            suppliesEvent: stdlib.validation
                .object()
                .keys({
                    id: SuppliesEvent.ID_VALIDATION.required(),
                })
                .required(),
        })
        .required();

    public static DEPENDENCIES = [SuppliesEventGatewayInterface];

    private readonly now: Date;
    private readonly suppliesEventGateway: SuppliesEventGatewayInterface;

    public constructor(dependencies: {
        date: Date;
        SuppliesEventGatewayInterface: SuppliesEventGatewayInterface;
    }) {
        this.now = dependencies.date;
        this.suppliesEventGateway = dependencies.SuppliesEventGatewayInterface;
    }

    public async run(
        viewer: Viewer,
        input: GetAllSuppliesUsecaseInput,
    ): Promise<GetAllSuppliesUsecaseOutput> {
        const output: GetAllSuppliesUsecaseOutput = {
            success: false,
            suppliesEvent: undefined,
        };

        let suppliesEvent: SuppliesEvent;

        suppliesEvent = await SuppliesEvent.genSuppliesEventById(
            viewer,
            this.suppliesEventGateway,
            input.suppliesEvent.id,
        );
        if (!suppliesEvent) {
            return output;
        }

        output.suppliesEvent = suppliesEvent;

        output.success = true;
        return output;
    }
}
