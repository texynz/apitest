// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    InfrastructureEventResource,
    InfrastructureEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    GetAllInfrastructureUsecase,
    GetAllInfrastructureUsecaseInput,
    GetAllInfrastructureUsecaseOutput,
} from '../../usecases';

export interface PostGetAllInfrastructureEndpointInput {
    body: GetAllInfrastructureUsecaseInput['infrastructureEvent'];
}

export interface PostGetAllInfrastructureEndpointOutput {
    success: boolean;
    data?: InfrastructureEventResourceInterface;
}

export default class PostGetAllInfrastructureEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized(
            'endpoint:PostGetAllInfrastructureEndpoint',
        );
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: GetAllInfrastructureUsecase.INPUT_VALIDATION.extract(
                'infrastructureEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [GetAllInfrastructureUsecase];

    private readonly now: Date;
    private readonly getAllInfrastructureUsecase: GetAllInfrastructureUsecase;

    public constructor(dependencies: {
        date: Date;
        GetAllInfrastructureUsecase: GetAllInfrastructureUsecase;
    }) {
        this.now = dependencies.date;
        this.getAllInfrastructureUsecase =
            dependencies.GetAllInfrastructureUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostGetAllInfrastructureEndpointInput,
    ): Promise<PostGetAllInfrastructureEndpointOutput> {
        const output: PostGetAllInfrastructureEndpointOutput = {
            success: false,
        };

        let resource: InfrastructureEventResourceInterface;
        let usecaseInput: GetAllInfrastructureUsecaseInput;
        let usecaseOutput: GetAllInfrastructureUsecaseOutput;

        usecaseInput = {
            infrastructureEvent: {
                id: undefined,
            },
        };

        usecaseInput.infrastructureEvent = input.body;

        usecaseOutput = await this.getAllInfrastructureUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = InfrastructureEventResource.toInfrastructureEventResource(
            usecaseOutput.infrastructureEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
