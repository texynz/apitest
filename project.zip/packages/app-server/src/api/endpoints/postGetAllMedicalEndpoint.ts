// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    MedicalEventResource,
    MedicalEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    GetAllMedicalUsecase,
    GetAllMedicalUsecaseInput,
    GetAllMedicalUsecaseOutput,
} from '../../usecases';

export interface PostGetAllMedicalEndpointInput {
    body: GetAllMedicalUsecaseInput['medicalEvent'];
}

export interface PostGetAllMedicalEndpointOutput {
    success: boolean;
    data?: MedicalEventResourceInterface;
}

export default class PostGetAllMedicalEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized('endpoint:PostGetAllMedicalEndpoint');
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: GetAllMedicalUsecase.INPUT_VALIDATION.extract(
                'medicalEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [GetAllMedicalUsecase];

    private readonly now: Date;
    private readonly getAllMedicalUsecase: GetAllMedicalUsecase;

    public constructor(dependencies: {
        date: Date;
        GetAllMedicalUsecase: GetAllMedicalUsecase;
    }) {
        this.now = dependencies.date;
        this.getAllMedicalUsecase = dependencies.GetAllMedicalUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostGetAllMedicalEndpointInput,
    ): Promise<PostGetAllMedicalEndpointOutput> {
        const output: PostGetAllMedicalEndpointOutput = {
            success: false,
        };

        let resource: MedicalEventResourceInterface;
        let usecaseInput: GetAllMedicalUsecaseInput;
        let usecaseOutput: GetAllMedicalUsecaseOutput;

        usecaseInput = {
            medicalEvent: {
                id: undefined,
            },
        };

        usecaseInput.medicalEvent = input.body;

        usecaseOutput = await this.getAllMedicalUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = MedicalEventResource.toMedicalEventResource(
            usecaseOutput.medicalEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
