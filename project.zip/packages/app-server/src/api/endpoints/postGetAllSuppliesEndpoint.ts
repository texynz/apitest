// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    SuppliesEventResource,
    SuppliesEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    GetAllSuppliesUsecase,
    GetAllSuppliesUsecaseInput,
    GetAllSuppliesUsecaseOutput,
} from '../../usecases';

export interface PostGetAllSuppliesEndpointInput {
    body: GetAllSuppliesUsecaseInput['suppliesEvent'];
}

export interface PostGetAllSuppliesEndpointOutput {
    success: boolean;
    data?: SuppliesEventResourceInterface;
}

export default class PostGetAllSuppliesEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized('endpoint:PostGetAllSuppliesEndpoint');
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: GetAllSuppliesUsecase.INPUT_VALIDATION.extract(
                'suppliesEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [GetAllSuppliesUsecase];

    private readonly now: Date;
    private readonly getAllSuppliesUsecase: GetAllSuppliesUsecase;

    public constructor(dependencies: {
        date: Date;
        GetAllSuppliesUsecase: GetAllSuppliesUsecase;
    }) {
        this.now = dependencies.date;
        this.getAllSuppliesUsecase = dependencies.GetAllSuppliesUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostGetAllSuppliesEndpointInput,
    ): Promise<PostGetAllSuppliesEndpointOutput> {
        const output: PostGetAllSuppliesEndpointOutput = {
            success: false,
        };

        let resource: SuppliesEventResourceInterface;
        let usecaseInput: GetAllSuppliesUsecaseInput;
        let usecaseOutput: GetAllSuppliesUsecaseOutput;

        usecaseInput = {
            suppliesEvent: {
                id: undefined,
            },
        };

        usecaseInput.suppliesEvent = input.body;

        usecaseOutput = await this.getAllSuppliesUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = SuppliesEventResource.toSuppliesEventResource(
            usecaseOutput.suppliesEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
