// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    MedicalEventResource,
    MedicalEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    CreateMedicalResponseUsecase,
    CreateMedicalResponseUsecaseInput,
    CreateMedicalResponseUsecaseOutput,
} from '../../usecases';

export interface PostCreateMedicalResponseEndpointInput {
    body: CreateMedicalResponseUsecaseInput['medicalEvent'];
}

export interface PostCreateMedicalResponseEndpointOutput {
    success: boolean;
    data?: MedicalEventResourceInterface;
}

export default class PostCreateMedicalResponseEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized(
            'endpoint:PostCreateMedicalResponseEndpoint',
        );
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: CreateMedicalResponseUsecase.INPUT_VALIDATION.extract(
                'medicalEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [CreateMedicalResponseUsecase];

    private readonly now: Date;
    private readonly createMedicalResponseUsecase: CreateMedicalResponseUsecase;

    public constructor(dependencies: {
        date: Date;
        CreateMedicalResponseUsecase: CreateMedicalResponseUsecase;
    }) {
        this.now = dependencies.date;
        this.createMedicalResponseUsecase =
            dependencies.CreateMedicalResponseUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostCreateMedicalResponseEndpointInput,
    ): Promise<PostCreateMedicalResponseEndpointOutput> {
        const output: PostCreateMedicalResponseEndpointOutput = {
            success: false,
        };

        let resource: MedicalEventResourceInterface;
        let usecaseInput: CreateMedicalResponseUsecaseInput;
        let usecaseOutput: CreateMedicalResponseUsecaseOutput;

        usecaseInput = {
            medicalEvent: {
                eventid: undefined,
                lat: undefined,
                lng: undefined,
                mentalLevel: undefined,
                physicalPriority: undefined,
                reportDateTime: undefined,
                reportType: undefined,
                updateDateTime: undefined,
            },
        };

        usecaseInput.medicalEvent = input.body;

        usecaseOutput = await this.createMedicalResponseUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = MedicalEventResource.toMedicalEventResource(
            usecaseOutput.medicalEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
