// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    InfrastructureEventResource,
    InfrastructureEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    CreateInfrastructureResponseUsecase,
    CreateInfrastructureResponseUsecaseInput,
    CreateInfrastructureResponseUsecaseOutput,
} from '../../usecases';

export interface PostCreateInfrastructureResponseEndpointInput {
    body: CreateInfrastructureResponseUsecaseInput['infrastructureEvent'];
}

export interface PostCreateInfrastructureResponseEndpointOutput {
    success: boolean;
    data?: InfrastructureEventResourceInterface;
}

export default class PostCreateInfrastructureResponseEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized(
            'endpoint:PostCreateInfrastructureResponseEndpoint',
        );
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: CreateInfrastructureResponseUsecase.INPUT_VALIDATION.extract(
                'infrastructureEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [CreateInfrastructureResponseUsecase];

    private readonly now: Date;
    private readonly createInfrastructureResponseUsecase: CreateInfrastructureResponseUsecase;

    public constructor(dependencies: {
        date: Date;
        CreateInfrastructureResponseUsecase: CreateInfrastructureResponseUsecase;
    }) {
        this.now = dependencies.date;
        this.createInfrastructureResponseUsecase =
            dependencies.CreateInfrastructureResponseUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostCreateInfrastructureResponseEndpointInput,
    ): Promise<PostCreateInfrastructureResponseEndpointOutput> {
        const output: PostCreateInfrastructureResponseEndpointOutput = {
            success: false,
        };

        let resource: InfrastructureEventResourceInterface;
        let usecaseInput: CreateInfrastructureResponseUsecaseInput;
        let usecaseOutput: CreateInfrastructureResponseUsecaseOutput;

        usecaseInput = {
            infrastructureEvent: {
                blocked: undefined,
                cracks: undefined,
                damageLevel: undefined,
                eventid: undefined,
                lat: undefined,
                lng: undefined,
                looseChips: undefined,
                potHoles: undefined,
                reportDateTime: undefined,
                reportType: undefined,
                slips: undefined,
                updateDateTime: undefined,
            },
        };

        usecaseInput.infrastructureEvent = input.body;

        usecaseOutput = await this.createInfrastructureResponseUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = InfrastructureEventResource.toInfrastructureEventResource(
            usecaseOutput.infrastructureEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
