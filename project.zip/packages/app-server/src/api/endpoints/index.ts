// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

// NPM Packages
import stdlib from '@local/server-stdlib';
import bodyParser from 'body-parser';
import PostCreateInfrastructureResponseEndpoint from './postCreateInfrastructureResponseEndpoint';
import PostCreateMedicalResponseEndpoint from './postCreateMedicalResponseEndpoint';
import PostCreateSuppliesResponseEndpoint from './postCreateSuppliesResponseEndpoint';
import PostGetAllInfrastructureEndpoint from './postGetAllInfrastructureEndpoint';
import PostGetAllMedicalEndpoint from './postGetAllMedicalEndpoint';
import PostGetAllSuppliesEndpoint from './postGetAllSuppliesEndpoint';

export default function endpointsMiddleware(app) {
    // Enable json bodies
    app.use('/api/rest', bodyParser.json());
    app.post(
        '/api/rest/createInfrastructureResponse',
        stdlib.rest.endpoint(PostCreateInfrastructureResponseEndpoint),
    );
    app.post(
        '/api/rest/createMedicalResponse',
        stdlib.rest.endpoint(PostCreateMedicalResponseEndpoint),
    );
    app.post(
        '/api/rest/createSuppliesResponse',
        stdlib.rest.endpoint(PostCreateSuppliesResponseEndpoint),
    );
    app.post(
        '/api/rest/getAllInfrastructure',
        stdlib.rest.endpoint(PostGetAllInfrastructureEndpoint),
    );
    app.post(
        '/api/rest/getAllMedical',
        stdlib.rest.endpoint(PostGetAllMedicalEndpoint),
    );
    app.post(
        '/api/rest/getAllSupplies',
        stdlib.rest.endpoint(PostGetAllSuppliesEndpoint),
    );
}
