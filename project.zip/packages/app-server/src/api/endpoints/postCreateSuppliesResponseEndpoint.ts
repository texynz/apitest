// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib from '@local/server-stdlib';
import {
    SupplieslEventResource,
    SupplieslEventResourceInterface,
} from '../../api/resources';
import Viewer from '../../server/viewer';
import {
    CreateSuppliesResponseUsecase,
    CreateSuppliesResponseUsecaseInput,
    CreateSuppliesResponseUsecaseOutput,
} from '../../usecases';

export interface PostCreateSuppliesResponseEndpointInput {
    body: CreateSuppliesResponseUsecaseInput['suppliesEvent'];
}

export interface PostCreateSuppliesResponseEndpointOutput {
    success: boolean;
    data?: SupplieslEventResourceInterface;
}

export default class PostCreateSuppliesResponseEndpoint {
    public static async assertAuthorized(viewer: Viewer) {
        await viewer.assertAuthorized(
            'endpoint:PostCreateSuppliesResponseEndpoint',
        );
    }

    public static INPUT_VALIDATION = stdlib.validation
        .object()
        .keys({
            body: CreateSuppliesResponseUsecase.INPUT_VALIDATION.extract(
                'suppliesEvent',
            ).required(),
        })
        .required();

    public static DEPENDENCIES = [CreateSuppliesResponseUsecase];

    private readonly now: Date;
    private readonly createSuppliesResponseUsecase: CreateSuppliesResponseUsecase;

    public constructor(dependencies: {
        date: Date;
        CreateSuppliesResponseUsecase: CreateSuppliesResponseUsecase;
    }) {
        this.now = dependencies.date;
        this.createSuppliesResponseUsecase =
            dependencies.CreateSuppliesResponseUsecase;
    }

    public async run(
        viewer: Viewer,
        input: PostCreateSuppliesResponseEndpointInput,
    ): Promise<PostCreateSuppliesResponseEndpointOutput> {
        const output: PostCreateSuppliesResponseEndpointOutput = {
            success: false,
        };

        let resource: SupplieslEventResourceInterface;
        let usecaseInput: CreateSuppliesResponseUsecaseInput;
        let usecaseOutput: CreateSuppliesResponseUsecaseOutput;

        usecaseInput = {
            suppliesEvent: {
                eventid: undefined,
                foodSupply: undefined,
                lat: undefined,
                lng: undefined,
                reportDateTime: undefined,
                reportType: undefined,
                updateDateTime: undefined,
                waterSupply: undefined,
            },
        };

        usecaseInput.suppliesEvent = input.body;

        usecaseOutput = await this.createSuppliesResponseUsecase.run(
            viewer,
            usecaseInput,
        );
        if (!usecaseOutput.success) {
            return output;
        }

        resource = SupplieslEventResource.toSupplieslEventResource(
            usecaseOutput.suppliesEvent,
        ) as any;

        output.data = resource;

        output.success = true;
        return output;
    }
}
