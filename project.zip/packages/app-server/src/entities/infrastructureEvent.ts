// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib, { StdlibTypes } from '@local/server-stdlib';
import Viewer from '../server/viewer';

export class InfrastructureEventGatewayInterface {
    public async createInfrastructureEvent(
        viewer,
        infrastructureEvent: InfrastructureEvent,
    ): Promise<boolean | void> {}

    public async genInfrastructureEventById(
        viewer,
        id,
    ): Promise<InfrastructureEvent | null | void> {}

    public async genInfrastructureEventsWhere(
        viewer,
        criteria,
        sort: string[],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<InfrastructureEvent[]> {
        return [];
    }
}

export default class InfrastructureEvent {
    public static ID_VALIDATION = stdlib.validation.id();

    public static CREATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static UPDATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static BLOCKED_VALIDATION = stdlib.validation.boolean();

    public static CRACKS_VALIDATION = stdlib.validation.boolean();

    public static DAMAGE_LEVEL_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(5);

    public static DATA_CREDIBILITY_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(6);

    public static DATA_RELIABILITY_VALIDATION = stdlib.validation
        .string()
        .valid('A', 'B', 'C', 'D', 'E', 'F');

    public static EVENTID_VALIDATION = stdlib.validation.id();

    public static LAT_VALIDATION = stdlib.validation.number();

    public static LNG_VALIDATION = stdlib.validation.number();

    public static LOOSE_CHIPS_VALIDATION = stdlib.validation.boolean();

    public static POT_HOLES_VALIDATION = stdlib.validation.boolean();

    public static REPORT_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static REPORT_TYPE_VALIDATION = stdlib.validation
        .string()
        .valid('medicalReport');

    public static SLIPS_VALIDATION = stdlib.validation.boolean();

    public static UPDATE_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static $VALIDATION = stdlib.validation
        .object()
        .keys({
            id: InfrastructureEvent.ID_VALIDATION,
            createdAt: InfrastructureEvent.CREATED_AT_VALIDATION,
            updatedAt: InfrastructureEvent.UPDATED_AT_VALIDATION,
            blocked: InfrastructureEvent.BLOCKED_VALIDATION,
            cracks: InfrastructureEvent.CRACKS_VALIDATION,
            damageLevel: InfrastructureEvent.DAMAGE_LEVEL_VALIDATION,
            dataCredibility: InfrastructureEvent.DATA_CREDIBILITY_VALIDATION,
            dataReliability: InfrastructureEvent.DATA_RELIABILITY_VALIDATION,
            eventid: InfrastructureEvent.EVENTID_VALIDATION,
            lat: InfrastructureEvent.LAT_VALIDATION,
            lng: InfrastructureEvent.LNG_VALIDATION,
            looseChips: InfrastructureEvent.LOOSE_CHIPS_VALIDATION,
            potHoles: InfrastructureEvent.POT_HOLES_VALIDATION,
            reportDateTime: InfrastructureEvent.REPORT_DATE_TIME_VALIDATION,
            reportType: InfrastructureEvent.REPORT_TYPE_VALIDATION,
            slips: InfrastructureEvent.SLIPS_VALIDATION,
            updateDateTime: InfrastructureEvent.UPDATE_DATE_TIME_VALIDATION,
        });

    public id: string;
    public createdAt: Date;
    public updatedAt: Date;
    public blocked: boolean;
    public cracks: boolean;
    public damageLevel: number;
    public dataCredibility: number;
    public dataReliability: string;
    public eventid: string;
    public lat: number;
    public lng: number;
    public looseChips: boolean;
    public potHoles: boolean;
    public reportDateTime: Date;
    public reportType: string;
    public slips: boolean;
    public updateDateTime: Date;

    // This is does so we can compare what has changed between updates
    public $stored: {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        blocked: boolean;
        cracks: boolean;
        damageLevel: number;
        dataCredibility: number;
        dataReliability: string;
        eventid: string;
        lat: number;
        lng: number;
        looseChips: boolean;
        potHoles: boolean;
        reportDateTime: Date;
        reportType: string;
        slips: boolean;
        updateDateTime: Date;
    };

    public constructor(viewer: Viewer, data) {
        this.id = '';
        this.createdAt = undefined;
        this.updatedAt = undefined;
        this.blocked = undefined;
        this.cracks = undefined;
        this.damageLevel = undefined;
        this.dataCredibility = undefined;
        this.dataReliability = '';
        this.eventid = '';
        this.lat = undefined;
        this.lng = undefined;
        this.looseChips = undefined;
        this.potHoles = undefined;
        this.reportDateTime = undefined;
        this.reportType = '';
        this.slips = undefined;
        this.updateDateTime = undefined;
        this.id = data.id ?? this.id;
        this.createdAt = data.createdAt
            ? new Date(data.createdAt)
            : this.createdAt;
        this.updatedAt = data.updatedAt
            ? new Date(data.updatedAt)
            : this.updatedAt;
        this.blocked = data.blocked ?? this.blocked;
        this.cracks = data.cracks ?? this.cracks;
        this.damageLevel = data.damageLevel ?? this.damageLevel;
        this.dataCredibility = data.dataCredibility ?? this.dataCredibility;
        this.dataReliability = data.dataReliability ?? this.dataReliability;
        this.eventid = data.eventid ?? this.eventid;
        this.lat = data.lat ?? this.lat;
        this.lng = data.lng ?? this.lng;
        this.looseChips = data.looseChips ?? this.looseChips;
        this.potHoles = data.potHoles ?? this.potHoles;
        this.reportDateTime = data.reportDateTime
            ? new Date(data.reportDateTime)
            : this.reportDateTime;
        this.reportType = data.reportType ?? this.reportType;
        this.slips = data.slips ?? this.slips;
        this.updateDateTime = data.updateDateTime
            ? new Date(data.updateDateTime)
            : this.updateDateTime;

        this.$stored = stdlib.entity.clone(this);
    }

    public static genId(): string {
        return stdlib.entity.genId();
    }

    public static async checkIdIntegrity(
        viewer: Viewer,
        gateway: InfrastructureEventGatewayInterface,
        infrastructureEvent: InfrastructureEvent,
    ): Promise<boolean> {
        const uniqueInfrastructureEvent = await InfrastructureEvent.genInfrastructureEventById(
            viewer,
            gateway,
            infrastructureEvent.id,
        );
        if (
            uniqueInfrastructureEvent &&
            uniqueInfrastructureEvent.id !== infrastructureEvent.$stored.id
        ) {
            return false;
        }

        return true;
    }

    public static async createInfrastructureEvent(
        viewer: Viewer,
        gateway: InfrastructureEventGatewayInterface,
        infrastructureEvent: InfrastructureEvent,
    ): Promise<InfrastructureEvent | null> {
        let newEntity = new InfrastructureEvent(viewer, infrastructureEvent);
        const { $stored } = newEntity;
        delete newEntity.$stored;
        await stdlib.entity.validate(
            newEntity,
            InfrastructureEvent.$VALIDATION,
        );

        const permittedWriteData = await viewer.assertAuthorizedData(
            'create:InfrastructureEvent',
            newEntity,
        );
        const isCreated = await gateway.createInfrastructureEvent(
            viewer,
            permittedWriteData,
        );
        if (!isCreated) {
            return null;
        }
        const permittedReadData = await viewer.readAuthorizedData(
            'read:InfrastructureEvent',
            $stored,
        );
        newEntity = new InfrastructureEvent(viewer, permittedReadData);
        return newEntity;
    }

    public static async genInfrastructureEventById(
        viewer: Viewer,
        gateway: InfrastructureEventGatewayInterface,
        id,
    ): Promise<InfrastructureEvent | null> {
        const fullData = await gateway.genInfrastructureEventById(viewer, id);
        if (!fullData) {
            return null;
        }
        const fullEntity = new InfrastructureEvent(viewer, fullData);
        const permittedData = await viewer.readAuthorizedData(
            'read:InfrastructureEvent',
            fullEntity,
        );
        // This means that their is no authorized model for this object
        if (!permittedData) {
            return null;
        }
        const permittedEntity = new InfrastructureEvent(viewer, permittedData);
        return permittedEntity;
    }

    public static async genInfrastructureEventsWhere(
        viewer: Viewer,
        gateway: InfrastructureEventGatewayInterface,
        criteria,
        sort: string[] = [],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<InfrastructureEvent[]> {
        const strictCriteria = await viewer.genAuthorizedCriteria(
            'read:InfrastructureEvent',
            criteria,
        );
        const list = await gateway.genInfrastructureEventsWhere(
            viewer,
            strictCriteria,
            sort,
            page,
        );
        if (!list.length) {
            return [];
        }
        const instances: InfrastructureEvent[] = [];
        await Promise.all(
            list.map(async (fullData) => {
                if (!fullData) {
                    return;
                }
                const fullEntity = new InfrastructureEvent(viewer, fullData);
                const permittedData = await viewer.readAuthorizedData(
                    'read:InfrastructureEvent',
                    fullEntity,
                );
                // This means that their is no authorized model for this object
                if (!permittedData) {
                    return;
                }
                const permittedEntity = new InfrastructureEvent(
                    viewer,
                    permittedData,
                );
                instances.push(permittedEntity);
            }),
        );
        return instances;
    }
}
