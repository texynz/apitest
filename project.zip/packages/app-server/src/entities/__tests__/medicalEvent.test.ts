// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import { MedicalEvent } from '../index';

describe('MedicalEvent id #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an id, then succeed', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = 'cuid4v2yj000001mmbvjwa4ya';
            const output = 'cuid4v2yj000001mmbvjwa4ya';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an empty input, then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = '';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input not matching the required pattern (/c[a-zA-Z0-9]{24}/), then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = 'auid4v2yj000001mmbvjwa4ya';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input not equal to the required length (25), then fail', async () => {
            const rule = MedicalEvent.ID_VALIDATION;
            const input = 'cp9uusf6u8ocvd6hjwqaqc6al9';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent createdAt #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an ISO 8601 date, then succeed', async () => {
            const rule = MedicalEvent.CREATED_AT_VALIDATION;
            const input = '1969-07-16T13:32:00.000Z';
            const output = new Date('1969-07-16T13:32:00.000Z');
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input that is a non ISO 8601 date format, then fail', async () => {
            const rule = MedicalEvent.CREATED_AT_VALIDATION;
            const input = 'Wed, 06 Mar 2019 09:09:00 +0000';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.CREATED_AT_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.CREATED_AT_VALIDATION;
            const input = false;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.CREATED_AT_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent updatedAt #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an ISO 8601 date, then succeed', async () => {
            const rule = MedicalEvent.UPDATED_AT_VALIDATION;
            const input = '1969-07-16T13:32:00.000Z';
            const output = new Date('1969-07-16T13:32:00.000Z');
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input that is a non ISO 8601 date format, then fail', async () => {
            const rule = MedicalEvent.UPDATED_AT_VALIDATION;
            const input = 'Wed, 06 Mar 2019 09:09:00 +0000';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.UPDATED_AT_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.UPDATED_AT_VALIDATION;
            const input = false;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.UPDATED_AT_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent dataCredibility #validation', () => {
    describe('Happy path', () => {
        it('Given an input with the minimum value (1), then succeed', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 1;
            const output = 1;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with the maximum value (6), then succeed', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 6;
            const output = 6;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 4;
            const output = 4;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a random value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 6;
            const output = 6;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input of type "string", then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 'spartan';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input that is a non-integer number, then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 1.17;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input less than the minimum value (1), then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 0;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input greater than the maximum value (6), then fail', async () => {
            const rule = MedicalEvent.DATA_CREDIBILITY_VALIDATION;
            const input = 7;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent dataReliability #validation', () => {
    describe('Happy path', () => {
        it('Given an input equal to "A", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'A';
            const output = 'A';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "B", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'B';
            const output = 'B';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "C", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'C';
            const output = 'C';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "D", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'D';
            const output = 'D';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "E", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'E';
            const output = 'E';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "F", then succeed', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 'F';
            const output = 'F';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given the input "", that is not one of [A, B, C, D, E, F], then fail', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = '';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "117", that is not one of [A, B, C, D, E, F], then fail', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "true", that is not one of [A, B, C, D, E, F], then fail', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "null", that is not one of [A, B, C, D, E, F], then fail', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "[A]", that is not one of [A, B, C, D, E, F], then fail', async () => {
            const rule = MedicalEvent.DATA_RELIABILITY_VALIDATION;
            const input = '[A]';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent eventid #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an id, then succeed', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = 'cuid4v2yj000001mmbvjwa4ya';
            const output = 'cuid4v2yj000001mmbvjwa4ya';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an empty input, then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = '';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input not matching the required pattern (/c[a-zA-Z0-9]{24}/), then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = 'auid4v2yj000001mmbvjwa4ya';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input not equal to the required length (25), then fail', async () => {
            const rule = MedicalEvent.EVENTID_VALIDATION;
            const input = 'cp9uusf6u8ocvd6hjwqaqc6al9';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent lat #validation', () => {
    describe('Happy path', () => {
        it('Given an input with a value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.LAT_VALIDATION;
            const input = 50;
            const output = 50;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a random value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.LAT_VALIDATION;
            const input = 96.931767;
            const output = 96.931767;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input of type "string", then fail', async () => {
            const rule = MedicalEvent.LAT_VALIDATION;
            const input = 'spartan';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.LAT_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.LAT_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent lng #validation', () => {
    describe('Happy path', () => {
        it('Given an input with a value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.LNG_VALIDATION;
            const input = 50;
            const output = 50;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a random value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.LNG_VALIDATION;
            const input = 96.931767;
            const output = 96.931767;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input of type "string", then fail', async () => {
            const rule = MedicalEvent.LNG_VALIDATION;
            const input = 'spartan';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.LNG_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.LNG_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent mentalLevel #validation', () => {
    describe('Happy path', () => {
        it('Given an input with the minimum value (1), then succeed', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 1;
            const output = 1;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with the maximum value (5), then succeed', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 5;
            const output = 5;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 3;
            const output = 3;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input with a random value between the minimum and maximum values, then succeed', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 5;
            const output = 5;
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input of type "string", then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 'spartan';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input that is a non-integer number, then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 1.17;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input less than the minimum value (1), then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 0;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input greater than the maximum value (5), then fail', async () => {
            const rule = MedicalEvent.MENTAL_LEVEL_VALIDATION;
            const input = 6;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent physicalPriority #validation', () => {
    describe('Happy path', () => {
        it('Given an input equal to "P1", then succeed', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = 'P1';
            const output = 'P1';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "P2", then succeed', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = 'P2';
            const output = 'P2';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });

        it('Given an input equal to "P3", then succeed', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = 'P3';
            const output = 'P3';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given the input "", that is not one of [P1, P2, P3], then fail', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = '';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "117", that is not one of [P1, P2, P3], then fail', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "true", that is not one of [P1, P2, P3], then fail', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "null", that is not one of [P1, P2, P3], then fail', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "[P1]", that is not one of [P1, P2, P3], then fail', async () => {
            const rule = MedicalEvent.PHYSICAL_PRIORITY_VALIDATION;
            const input = '[P1]';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent reportDateTime #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an ISO 8601 date, then succeed', async () => {
            const rule = MedicalEvent.REPORT_DATE_TIME_VALIDATION;
            const input = '1969-07-16T13:32:00.000Z';
            const output = new Date('1969-07-16T13:32:00.000Z');
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input that is a non ISO 8601 date format, then fail', async () => {
            const rule = MedicalEvent.REPORT_DATE_TIME_VALIDATION;
            const input = 'Wed, 06 Mar 2019 09:09:00 +0000';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.REPORT_DATE_TIME_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.REPORT_DATE_TIME_VALIDATION;
            const input = false;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.REPORT_DATE_TIME_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent reportType #validation', () => {
    describe('Happy path', () => {
        it('Given an input equal to "medicalReport", then succeed', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = 'medicalReport';
            const output = 'medicalReport';
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given the input "", that is not [medicalReport], then fail', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = '';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "117", that is not [medicalReport], then fail', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "true", that is not [medicalReport], then fail', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = true;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "null", that is not [medicalReport], then fail', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given the input "[medicalReport]", that is not [medicalReport], then fail', async () => {
            const rule = MedicalEvent.REPORT_TYPE_VALIDATION;
            const input = '[medicalReport]';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});

describe('MedicalEvent updateDateTime #validation', () => {
    describe('Happy path', () => {
        it('Given an input that is an ISO 8601 date, then succeed', async () => {
            const rule = MedicalEvent.UPDATE_DATE_TIME_VALIDATION;
            const input = '1969-07-16T13:32:00.000Z';
            const output = new Date('1969-07-16T13:32:00.000Z');
            const result = await rule.validateAsync(input);
            expect(result).toEqual(output);
        });
    });

    describe('bad path', () => {
        it('Given an input that is a non ISO 8601 date format, then fail', async () => {
            const rule = MedicalEvent.UPDATE_DATE_TIME_VALIDATION;
            const input = 'Wed, 06 Mar 2019 09:09:00 +0000';
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "number", then fail', async () => {
            const rule = MedicalEvent.UPDATE_DATE_TIME_VALIDATION;
            const input = 117;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "boolean", then fail', async () => {
            const rule = MedicalEvent.UPDATE_DATE_TIME_VALIDATION;
            const input = false;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });

        it('Given an input of type "null", then fail', async () => {
            const rule = MedicalEvent.UPDATE_DATE_TIME_VALIDATION;
            const input = null;
            const result = rule.validateAsync(input);
            return expect(result).rejects.toThrowError(Error);
        });
    });
});
