// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib, { StdlibTypes } from '@local/server-stdlib';
import Viewer from '../server/viewer';

export class SuppliesEventGatewayInterface {
    public async createSuppliesEvent(
        viewer,
        suppliesEvent: SuppliesEvent,
    ): Promise<boolean | void> {}

    public async genSuppliesEventById(
        viewer,
        id,
    ): Promise<SuppliesEvent | null | void> {}

    public async genSuppliesEventsWhere(
        viewer,
        criteria,
        sort: string[],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<SuppliesEvent[]> {
        return [];
    }
}

export default class SuppliesEvent {
    public static ID_VALIDATION = stdlib.validation.id();

    public static CREATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static UPDATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static DATA_CREDIBILITY_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(6);

    public static DATA_RELIABILITY_VALIDATION = stdlib.validation
        .string()
        .valid('A', 'B', 'C', 'D', 'E', 'F');

    public static EVENTID_VALIDATION = stdlib.validation.id();

    public static FOOD_SUPPLY_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(14);

    public static LAT_VALIDATION = stdlib.validation.number();

    public static LNG_VALIDATION = stdlib.validation.number();

    public static REPORT_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static REPORT_TYPE_VALIDATION = stdlib.validation
        .string()
        .valid('medicalReport');

    public static UPDATE_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static WATER_SUPPLY_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(14);

    public static $VALIDATION = stdlib.validation
        .object()
        .keys({
            id: SuppliesEvent.ID_VALIDATION,
            createdAt: SuppliesEvent.CREATED_AT_VALIDATION,
            updatedAt: SuppliesEvent.UPDATED_AT_VALIDATION,
            dataCredibility: SuppliesEvent.DATA_CREDIBILITY_VALIDATION,
            dataReliability: SuppliesEvent.DATA_RELIABILITY_VALIDATION,
            eventid: SuppliesEvent.EVENTID_VALIDATION,
            foodSupply: SuppliesEvent.FOOD_SUPPLY_VALIDATION,
            lat: SuppliesEvent.LAT_VALIDATION,
            lng: SuppliesEvent.LNG_VALIDATION,
            reportDateTime: SuppliesEvent.REPORT_DATE_TIME_VALIDATION,
            reportType: SuppliesEvent.REPORT_TYPE_VALIDATION,
            updateDateTime: SuppliesEvent.UPDATE_DATE_TIME_VALIDATION,
            waterSupply: SuppliesEvent.WATER_SUPPLY_VALIDATION,
        });

    public id: string;
    public createdAt: Date;
    public updatedAt: Date;
    public dataCredibility: number;
    public dataReliability: string;
    public eventid: string;
    public foodSupply: number;
    public lat: number;
    public lng: number;
    public reportDateTime: Date;
    public reportType: string;
    public updateDateTime: Date;
    public waterSupply: number;

    // This is does so we can compare what has changed between updates
    public $stored: {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        dataCredibility: number;
        dataReliability: string;
        eventid: string;
        foodSupply: number;
        lat: number;
        lng: number;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
        waterSupply: number;
    };

    public constructor(viewer: Viewer, data) {
        this.id = '';
        this.createdAt = undefined;
        this.updatedAt = undefined;
        this.dataCredibility = undefined;
        this.dataReliability = '';
        this.eventid = '';
        this.foodSupply = undefined;
        this.lat = undefined;
        this.lng = undefined;
        this.reportDateTime = undefined;
        this.reportType = '';
        this.updateDateTime = undefined;
        this.waterSupply = undefined;
        this.id = data.id ?? this.id;
        this.createdAt = data.createdAt
            ? new Date(data.createdAt)
            : this.createdAt;
        this.updatedAt = data.updatedAt
            ? new Date(data.updatedAt)
            : this.updatedAt;
        this.dataCredibility = data.dataCredibility ?? this.dataCredibility;
        this.dataReliability = data.dataReliability ?? this.dataReliability;
        this.eventid = data.eventid ?? this.eventid;
        this.foodSupply = data.foodSupply ?? this.foodSupply;
        this.lat = data.lat ?? this.lat;
        this.lng = data.lng ?? this.lng;
        this.reportDateTime = data.reportDateTime
            ? new Date(data.reportDateTime)
            : this.reportDateTime;
        this.reportType = data.reportType ?? this.reportType;
        this.updateDateTime = data.updateDateTime
            ? new Date(data.updateDateTime)
            : this.updateDateTime;
        this.waterSupply = data.waterSupply ?? this.waterSupply;

        this.$stored = stdlib.entity.clone(this);
    }

    public static genId(): string {
        return stdlib.entity.genId();
    }

    public static async checkIdIntegrity(
        viewer: Viewer,
        gateway: SuppliesEventGatewayInterface,
        suppliesEvent: SuppliesEvent,
    ): Promise<boolean> {
        const uniqueSuppliesEvent = await SuppliesEvent.genSuppliesEventById(
            viewer,
            gateway,
            suppliesEvent.id,
        );
        if (
            uniqueSuppliesEvent &&
            uniqueSuppliesEvent.id !== suppliesEvent.$stored.id
        ) {
            return false;
        }

        return true;
    }

    public static async createSuppliesEvent(
        viewer: Viewer,
        gateway: SuppliesEventGatewayInterface,
        suppliesEvent: SuppliesEvent,
    ): Promise<SuppliesEvent | null> {
        let newEntity = new SuppliesEvent(viewer, suppliesEvent);
        const { $stored } = newEntity;
        delete newEntity.$stored;
        await stdlib.entity.validate(newEntity, SuppliesEvent.$VALIDATION);

        const permittedWriteData = await viewer.assertAuthorizedData(
            'create:SuppliesEvent',
            newEntity,
        );
        const isCreated = await gateway.createSuppliesEvent(
            viewer,
            permittedWriteData,
        );
        if (!isCreated) {
            return null;
        }
        const permittedReadData = await viewer.readAuthorizedData(
            'read:SuppliesEvent',
            $stored,
        );
        newEntity = new SuppliesEvent(viewer, permittedReadData);
        return newEntity;
    }

    public static async genSuppliesEventById(
        viewer: Viewer,
        gateway: SuppliesEventGatewayInterface,
        id,
    ): Promise<SuppliesEvent | null> {
        const fullData = await gateway.genSuppliesEventById(viewer, id);
        if (!fullData) {
            return null;
        }
        const fullEntity = new SuppliesEvent(viewer, fullData);
        const permittedData = await viewer.readAuthorizedData(
            'read:SuppliesEvent',
            fullEntity,
        );
        // This means that their is no authorized model for this object
        if (!permittedData) {
            return null;
        }
        const permittedEntity = new SuppliesEvent(viewer, permittedData);
        return permittedEntity;
    }

    public static async genSuppliesEventsWhere(
        viewer: Viewer,
        gateway: SuppliesEventGatewayInterface,
        criteria,
        sort: string[] = [],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<SuppliesEvent[]> {
        const strictCriteria = await viewer.genAuthorizedCriteria(
            'read:SuppliesEvent',
            criteria,
        );
        const list = await gateway.genSuppliesEventsWhere(
            viewer,
            strictCriteria,
            sort,
            page,
        );
        if (!list.length) {
            return [];
        }
        const instances: SuppliesEvent[] = [];
        await Promise.all(
            list.map(async (fullData) => {
                if (!fullData) {
                    return;
                }
                const fullEntity = new SuppliesEvent(viewer, fullData);
                const permittedData = await viewer.readAuthorizedData(
                    'read:SuppliesEvent',
                    fullEntity,
                );
                // This means that their is no authorized model for this object
                if (!permittedData) {
                    return;
                }
                const permittedEntity = new SuppliesEvent(
                    viewer,
                    permittedData,
                );
                instances.push(permittedEntity);
            }),
        );
        return instances;
    }
}
