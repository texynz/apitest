// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

import stdlib, { StdlibTypes } from '@local/server-stdlib';
import Viewer from '../server/viewer';

export class MedicalEventGatewayInterface {
    public async createMedicalEvent(
        viewer,
        medicalEvent: MedicalEvent,
    ): Promise<boolean | void> {}

    public async genMedicalEventById(
        viewer,
        id,
    ): Promise<MedicalEvent | null | void> {}

    public async genMedicalEventsWhere(
        viewer,
        criteria,
        sort: string[],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<MedicalEvent[]> {
        return [];
    }
}

export default class MedicalEvent {
    public static ID_VALIDATION = stdlib.validation.id();

    public static CREATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static UPDATED_AT_VALIDATION = stdlib.validation.date().iso().utc();

    public static DATA_CREDIBILITY_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(6);

    public static DATA_RELIABILITY_VALIDATION = stdlib.validation
        .string()
        .valid('A', 'B', 'C', 'D', 'E', 'F');

    public static EVENTID_VALIDATION = stdlib.validation.id();

    public static LAT_VALIDATION = stdlib.validation.number();

    public static LNG_VALIDATION = stdlib.validation.number();

    public static MENTAL_LEVEL_VALIDATION = stdlib.validation
        .number()
        .integer()
        .min(1)
        .max(5);

    public static PHYSICAL_PRIORITY_VALIDATION = stdlib.validation
        .string()
        .valid('P1', 'P2', 'P3');

    public static REPORT_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static REPORT_TYPE_VALIDATION = stdlib.validation
        .string()
        .valid('medicalReport');

    public static UPDATE_DATE_TIME_VALIDATION = stdlib.validation
        .date()
        .iso()
        .utc();

    public static $VALIDATION = stdlib.validation
        .object()
        .keys({
            id: MedicalEvent.ID_VALIDATION,
            createdAt: MedicalEvent.CREATED_AT_VALIDATION,
            updatedAt: MedicalEvent.UPDATED_AT_VALIDATION,
            dataCredibility: MedicalEvent.DATA_CREDIBILITY_VALIDATION,
            dataReliability: MedicalEvent.DATA_RELIABILITY_VALIDATION,
            eventid: MedicalEvent.EVENTID_VALIDATION,
            lat: MedicalEvent.LAT_VALIDATION,
            lng: MedicalEvent.LNG_VALIDATION,
            mentalLevel: MedicalEvent.MENTAL_LEVEL_VALIDATION,
            physicalPriority: MedicalEvent.PHYSICAL_PRIORITY_VALIDATION,
            reportDateTime: MedicalEvent.REPORT_DATE_TIME_VALIDATION,
            reportType: MedicalEvent.REPORT_TYPE_VALIDATION,
            updateDateTime: MedicalEvent.UPDATE_DATE_TIME_VALIDATION,
        });

    public id: string;
    public createdAt: Date;
    public updatedAt: Date;
    public dataCredibility: number;
    public dataReliability: string;
    public eventid: string;
    public lat: number;
    public lng: number;
    public mentalLevel: number;
    public physicalPriority: string;
    public reportDateTime: Date;
    public reportType: string;
    public updateDateTime: Date;

    // This is does so we can compare what has changed between updates
    public $stored: {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        dataCredibility: number;
        dataReliability: string;
        eventid: string;
        lat: number;
        lng: number;
        mentalLevel: number;
        physicalPriority: string;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
    };

    public constructor(viewer: Viewer, data) {
        this.id = '';
        this.createdAt = undefined;
        this.updatedAt = undefined;
        this.dataCredibility = undefined;
        this.dataReliability = '';
        this.eventid = '';
        this.lat = undefined;
        this.lng = undefined;
        this.mentalLevel = undefined;
        this.physicalPriority = '';
        this.reportDateTime = undefined;
        this.reportType = '';
        this.updateDateTime = undefined;
        this.id = data.id ?? this.id;
        this.createdAt = data.createdAt
            ? new Date(data.createdAt)
            : this.createdAt;
        this.updatedAt = data.updatedAt
            ? new Date(data.updatedAt)
            : this.updatedAt;
        this.dataCredibility = data.dataCredibility ?? this.dataCredibility;
        this.dataReliability = data.dataReliability ?? this.dataReliability;
        this.eventid = data.eventid ?? this.eventid;
        this.lat = data.lat ?? this.lat;
        this.lng = data.lng ?? this.lng;
        this.mentalLevel = data.mentalLevel ?? this.mentalLevel;
        this.physicalPriority = data.physicalPriority ?? this.physicalPriority;
        this.reportDateTime = data.reportDateTime
            ? new Date(data.reportDateTime)
            : this.reportDateTime;
        this.reportType = data.reportType ?? this.reportType;
        this.updateDateTime = data.updateDateTime
            ? new Date(data.updateDateTime)
            : this.updateDateTime;

        this.$stored = stdlib.entity.clone(this);
    }

    public static genId(): string {
        return stdlib.entity.genId();
    }

    public static async checkIdIntegrity(
        viewer: Viewer,
        gateway: MedicalEventGatewayInterface,
        medicalEvent: MedicalEvent,
    ): Promise<boolean> {
        const uniqueMedicalEvent = await MedicalEvent.genMedicalEventById(
            viewer,
            gateway,
            medicalEvent.id,
        );
        if (
            uniqueMedicalEvent &&
            uniqueMedicalEvent.id !== medicalEvent.$stored.id
        ) {
            return false;
        }

        return true;
    }

    public static async createMedicalEvent(
        viewer: Viewer,
        gateway: MedicalEventGatewayInterface,
        medicalEvent: MedicalEvent,
    ): Promise<MedicalEvent | null> {
        let newEntity = new MedicalEvent(viewer, medicalEvent);
        const { $stored } = newEntity;
        delete newEntity.$stored;
        await stdlib.entity.validate(newEntity, MedicalEvent.$VALIDATION);

        const permittedWriteData = await viewer.assertAuthorizedData(
            'create:MedicalEvent',
            newEntity,
        );
        const isCreated = await gateway.createMedicalEvent(
            viewer,
            permittedWriteData,
        );
        if (!isCreated) {
            return null;
        }
        const permittedReadData = await viewer.readAuthorizedData(
            'read:MedicalEvent',
            $stored,
        );
        newEntity = new MedicalEvent(viewer, permittedReadData);
        return newEntity;
    }

    public static async genMedicalEventById(
        viewer: Viewer,
        gateway: MedicalEventGatewayInterface,
        id,
    ): Promise<MedicalEvent | null> {
        const fullData = await gateway.genMedicalEventById(viewer, id);
        if (!fullData) {
            return null;
        }
        const fullEntity = new MedicalEvent(viewer, fullData);
        const permittedData = await viewer.readAuthorizedData(
            'read:MedicalEvent',
            fullEntity,
        );
        // This means that their is no authorized model for this object
        if (!permittedData) {
            return null;
        }
        const permittedEntity = new MedicalEvent(viewer, permittedData);
        return permittedEntity;
    }

    public static async genMedicalEventsWhere(
        viewer: Viewer,
        gateway: MedicalEventGatewayInterface,
        criteria,
        sort: string[] = [],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<MedicalEvent[]> {
        const strictCriteria = await viewer.genAuthorizedCriteria(
            'read:MedicalEvent',
            criteria,
        );
        const list = await gateway.genMedicalEventsWhere(
            viewer,
            strictCriteria,
            sort,
            page,
        );
        if (!list.length) {
            return [];
        }
        const instances: MedicalEvent[] = [];
        await Promise.all(
            list.map(async (fullData) => {
                if (!fullData) {
                    return;
                }
                const fullEntity = new MedicalEvent(viewer, fullData);
                const permittedData = await viewer.readAuthorizedData(
                    'read:MedicalEvent',
                    fullEntity,
                );
                // This means that their is no authorized model for this object
                if (!permittedData) {
                    return;
                }
                const permittedEntity = new MedicalEvent(viewer, permittedData);
                instances.push(permittedEntity);
            }),
        );
        return instances;
    }
}
