// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

/* eslint-disable no-param-reassign */
import stdlib, { StdlibTypes } from '@local/server-stdlib';
import {
    applyCriteria,
    applySort,
    DateStorageModel,
} from '@local/server-stdlib/orm';
import Objection, { Model } from 'objection';
import { SuppliesEvent, SuppliesEventGatewayInterface } from '../entities';

class SupplyEventSchema extends Model {
    public static tableName = 'supply_event';
    public static idColumn = 'id';

    public static schema = {
        $table: SupplyEventSchema.tableName,
        id: 'id',
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
        dataCredibility: 'dataCredibility',
        dataReliability: 'dataReliability',
        eventid: 'eventid',
        foodSupply: 'foodSupply',
        lat: 'lat',
        lng: 'lng',
        reportDateTime: 'reportDateTime',
        reportType: 'reportType',
        updateDateTime: 'updateDateTime',
        waterSupply: 'waterSupply',
    };

    public id?: string;
    public createdAt?: Date;
    public updatedAt?: Date;
    public dataCredibility?: number;
    public dataReliability?: string;
    public eventid?: string;
    public foodSupply?: number;
    public lat?: number;
    public lng?: number;
    public reportDateTime?: Date;
    public reportType?: string;
    public updateDateTime?: Date;
    public waterSupply?: number;

    public static relationMappings = {};

    public $parseJson(
        json: Objection.Pojo,
        opt?: Objection.ModelOptions,
    ): Objection.Pojo {
        json = super.$parseJson(json, opt);
        return json;
    }

    public $formatJson(json: Objection.Pojo): Objection.Pojo {
        json = super.$formatJson(json);
        DateStorageModel.fromStorage(json, 'createdAt');
        DateStorageModel.fromStorage(json, 'updatedAt');
        DateStorageModel.fromStorage(json, 'reportDateTime');
        DateStorageModel.fromStorage(json, 'updateDateTime');
        return json;
    }
}

export default class SuppliesEventGateway extends SuppliesEventGatewayInterface {
    public async createSuppliesEvent(
        viewer,
        suppliesEvent: SuppliesEvent,
    ): Promise<boolean> {
        const connection = await viewer.genConnection(true);
        try {
            const data: Record<string, any> = suppliesEvent;
            const success = await SuppliesEventSchema.query(
                connection,
            ).insertGraph(data);
            if (!success) {
                await connection.rollback();
                return false;
            }
            await connection.commit();
            return true;
        } catch (exe) {
            await connection.rollback();
            throw new stdlib.createError.GatewayFailed(
                'Create entity failure',
                exe,
            );
        }
    }

    public async genSuppliesEventById(
        viewer,
        id,
    ): Promise<SuppliesEvent | null> {
        try {
            const connection = await viewer.genConnection();
            let suppliesEvent: Record<string, any>;
            const query = SuppliesEventSchema.query(connection)
                .withGraphFetched('*')
                .findOne('id', id);
            suppliesEvent = await query;

            if (!suppliesEvent) {
                return null;
            }

            // Convert our result into a DTO
            suppliesEvent = suppliesEvent.toJSON();
            return suppliesEvent as SuppliesEvent;
        } catch (exe) {
            throw new stdlib.createError.GatewayFailed(
                'Fetch entity failure',
                exe,
            );
        }
    }

    public async genSuppliesEventsWhere(
        viewer,
        criteria,
        sort: string[],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<SuppliesEvent[]> {
        try {
            const connection = await viewer.genConnection();
            let suppliesEvents: Record<string, any>[];
            const query = SuppliesEventSchema.query(
                connection,
            ).withGraphFetched('*');

            applyCriteria(query, SuppliesEventSchema.schema, criteria);
            applySort(query, SuppliesEventSchema.schema, sort);

            if (page) {
                query.offset(page.offset).limit(page.limit);
            }

            // Run the query
            suppliesEvents = await query;

            if (!suppliesEvents.length) {
                return [];
            }

            // Convert our result into a DTO
            suppliesEvents = suppliesEvents.map((item) => item.toJSON());

            return suppliesEvents as SuppliesEvent[];
        } catch (exe) {
            throw new stdlib.createError.GatewayFailed(
                'Fetch entities where failure',
                exe,
            );
        }
    }
}
