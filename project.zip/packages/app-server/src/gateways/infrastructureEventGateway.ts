// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

/* eslint-disable no-param-reassign */
import stdlib, { StdlibTypes } from '@local/server-stdlib';
import {
    applyCriteria,
    applySort,
    DateStorageModel,
} from '@local/server-stdlib/orm';
import Objection, { Model } from 'objection';
import {
    InfrastructureEvent,
    InfrastructureEventGatewayInterface,
} from '../entities';

class InfrastructureEventSchema extends Model {
    public static tableName = 'infrastructure_event';
    public static idColumn = 'id';

    public static schema = {
        $table: InfrastructureEventSchema.tableName,
        id: 'id',
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
        blocked: 'blocked',
        cracks: 'cracks',
        damageLevel: 'damageLevel',
        dataCredibility: 'dataCredibility',
        dataReliability: 'dataReliability',
        eventid: 'eventid',
        lat: 'lat',
        lng: 'lng',
        looseChips: 'looseChips',
        potHoles: 'potHoles',
        reportDateTime: 'reportDateTime',
        reportType: 'reportType',
        slips: 'slips',
        updateDateTime: 'updateDateTime',
    };

    public id?: string;
    public createdAt?: Date;
    public updatedAt?: Date;
    public blocked?: boolean;
    public cracks?: boolean;
    public damageLevel?: number;
    public dataCredibility?: number;
    public dataReliability?: string;
    public eventid?: string;
    public lat?: number;
    public lng?: number;
    public looseChips?: boolean;
    public potHoles?: boolean;
    public reportDateTime?: Date;
    public reportType?: string;
    public slips?: boolean;
    public updateDateTime?: Date;

    public static relationMappings = {};

    public $parseJson(
        json: Objection.Pojo,
        opt?: Objection.ModelOptions,
    ): Objection.Pojo {
        json = super.$parseJson(json, opt);
        return json;
    }

    public $formatJson(json: Objection.Pojo): Objection.Pojo {
        json = super.$formatJson(json);
        DateStorageModel.fromStorage(json, 'createdAt');
        DateStorageModel.fromStorage(json, 'updatedAt');
        DateStorageModel.fromStorage(json, 'reportDateTime');
        DateStorageModel.fromStorage(json, 'updateDateTime');
        return json;
    }
}

export default class InfrastructureEventGateway extends InfrastructureEventGatewayInterface {
    public async createInfrastructureEvent(
        viewer,
        infrastructureEvent: InfrastructureEvent,
    ): Promise<boolean> {
        const connection = await viewer.genConnection(true);
        try {
            const data: Record<string, any> = infrastructureEvent;
            const success = await InfrastructureEventSchema.query(
                connection,
            ).insertGraph(data);
            if (!success) {
                await connection.rollback();
                return false;
            }
            await connection.commit();
            return true;
        } catch (exe) {
            await connection.rollback();
            throw new stdlib.createError.GatewayFailed(
                'Create entity failure',
                exe,
            );
        }
    }

    public async genInfrastructureEventById(
        viewer,
        id,
    ): Promise<InfrastructureEvent | null> {
        try {
            const connection = await viewer.genConnection();
            let infrastructureEvent: Record<string, any>;
            const query = InfrastructureEventSchema.query(connection)
                .withGraphFetched('*')
                .findOne('id', id);
            infrastructureEvent = await query;

            if (!infrastructureEvent) {
                return null;
            }

            // Convert our result into a DTO
            infrastructureEvent = infrastructureEvent.toJSON();
            return infrastructureEvent as InfrastructureEvent;
        } catch (exe) {
            throw new stdlib.createError.GatewayFailed(
                'Fetch entity failure',
                exe,
            );
        }
    }

    public async genInfrastructureEventsWhere(
        viewer,
        criteria,
        sort: string[],
        page?: StdlibTypes['standards']['OffsetPaginationInput'],
    ): Promise<InfrastructureEvent[]> {
        try {
            const connection = await viewer.genConnection();
            let infrastructureEvents: Record<string, any>[];
            const query = InfrastructureEventSchema.query(
                connection,
            ).withGraphFetched('*');

            applyCriteria(query, InfrastructureEventSchema.schema, criteria);
            applySort(query, InfrastructureEventSchema.schema, sort);

            if (page) {
                query.offset(page.offset).limit(page.limit);
            }

            // Run the query
            infrastructureEvents = await query;

            if (!infrastructureEvents.length) {
                return [];
            }

            // Convert our result into a DTO
            infrastructureEvents = infrastructureEvents.map((item) =>
                item.toJSON(),
            );

            return infrastructureEvents as InfrastructureEvent[];
        } catch (exe) {
            throw new stdlib.createError.GatewayFailed(
                'Fetch entities where failure',
                exe,
            );
        }
    }
}
