// @graph-mind
// Remove the previous line to stop Ada from updating this file
// We inherit from the project files so tests are identical to the produced source code
const base = require('../../babel.config.js');

module.exports = {
    ...base,
};