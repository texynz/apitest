#!/usr/bin/env node
// @graph-mind
// Remove the previous line to stop Ada from updating this file


// eslint-disable-next-line import/no-unresolved
require('./index.body');