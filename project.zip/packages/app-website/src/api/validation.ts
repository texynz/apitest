// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots
import { Validation as yup } from '@local/website-stdlib';

export const postCreateMedicalResponseEndpointValidation = yup
    .object()
    .shape({
        eventid: yup.string().required('This field is required'),
        lat: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        lng: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        mentalLevel: yup
            .number()
            .integer('Must be a whole number')
            .typeError('Must be a whole number.')
            .required('This field is required'),
        physicalPriority: yup.string().required('This field is required'),
        reportDateTime: yup.date().required('This field is required'),
        reportType: yup.string().required('This field is required'),
        updateDateTime: yup.date().required('This field is required'),
    })
    .required('This field is required');

export const postCreateSuppliesResponseEndpointValidation = yup
    .object()
    .shape({
        eventid: yup.string().required('This field is required'),
        foodSupply: yup
            .number()
            .integer('Must be a whole number')
            .typeError('Must be a whole number.')
            .required('This field is required'),
        lat: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        lng: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        reportDateTime: yup.date().required('This field is required'),
        reportType: yup.string().required('This field is required'),
        updateDateTime: yup.date().required('This field is required'),
        waterSupply: yup
            .number()
            .integer('Must be a whole number')
            .typeError('Must be a whole number.')
            .required('This field is required'),
    })
    .required('This field is required');

export const postCreateInfrastructureResponseEndpointValidation = yup
    .object()
    .shape({
        blocked: yup.boolean().required('This field is required'),
        cracks: yup.boolean().required('This field is required'),
        damageLevel: yup
            .number()
            .integer('Must be a whole number')
            .typeError('Must be a whole number.')
            .required('This field is required'),
        eventid: yup.string().required('This field is required'),
        lat: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        lng: yup
            .number()
            .typeError('Must be a number.')
            .required('This field is required'),
        looseChips: yup.boolean().required('This field is required'),
        potHoles: yup.boolean().required('This field is required'),
        reportDateTime: yup.date().required('This field is required'),
        reportType: yup.string().required('This field is required'),
        slips: yup.boolean().required('This field is required'),
        updateDateTime: yup.date().required('This field is required'),
    })
    .required('This field is required');

export const postGetAllMedicalEndpointValidation = yup
    .object()
    .shape({ id: yup.string().required('This field is required') })
    .required('This field is required');

export const postGetAllSuppliesEndpointValidation = yup
    .object()
    .shape({ id: yup.string().required('This field is required') })
    .required('This field is required');

export const postGetAllInfrastructureEndpointValidation = yup
    .object()
    .shape({ id: yup.string().required('This field is required') })
    .required('This field is required');
