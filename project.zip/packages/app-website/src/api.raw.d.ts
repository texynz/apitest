// @graph-mind
// Remove the previous line to prevent this file from being modified by the robots

// Endpoint: POST(/createInfrastructureResponse)
export interface PostCreateInfrastructureResponseEndpointOutput {
    success: boolean;
    data?: InfrastructureEventResourceInterface;
}
export interface PostCreateInfrastructureResponseEndpointInput {
    body: {
        blocked: boolean;
        cracks: boolean;
        damageLevel: number;
        eventid: string;
        lat: number;
        lng: number;
        looseChips: boolean;
        potHoles: boolean;
        reportDateTime: Date;
        reportType: string;
        slips: boolean;
        updateDateTime: Date;
    };
}
// Endpoint: POST(/createMedicalResponse)
export interface PostCreateMedicalResponseEndpointOutput {
    success: boolean;
    data?: MedicalEventResourceInterface;
}
export interface PostCreateMedicalResponseEndpointInput {
    body: {
        eventid: string;
        lat: number;
        lng: number;
        mentalLevel: number;
        physicalPriority: string;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
    };
}
// Endpoint: POST(/createSuppliesResponse)
export interface PostCreateSuppliesResponseEndpointOutput {
    success: boolean;
    data?: SupplieslEventResourceInterface;
}
export interface PostCreateSuppliesResponseEndpointInput {
    body: {
        eventid: string;
        foodSupply: number;
        lat: number;
        lng: number;
        reportDateTime: Date;
        reportType: string;
        updateDateTime: Date;
        waterSupply: number;
    };
}
// Endpoint: POST(/getAllInfrastructure)
export interface PostGetAllInfrastructureEndpointOutput {
    success: boolean;
    data?: InfrastructureEventResourceInterface;
}
export interface PostGetAllInfrastructureEndpointInput {
    body: {
        id: string;
    };
}
// Endpoint: POST(/getAllMedical)
export interface PostGetAllMedicalEndpointOutput {
    success: boolean;
    data?: MedicalEventResourceInterface;
}
export interface PostGetAllMedicalEndpointInput {
    body: {
        id: string;
    };
}
// Endpoint: POST(/getAllSupplies)
export interface PostGetAllSuppliesEndpointOutput {
    success: boolean;
    data?: SuppliesEventResourceInterface;
}
export interface PostGetAllSuppliesEndpointInput {
    body: {
        id: string;
    };
}
